# CHANGELOG.md

## [4.0.1] - 2025-02-02

- Remove deprecated class name

## [4.0.0] - 2025-02-01

- Updgrade to Tailwind v4
- Update dependencies

## [3.1.0] - 2024-12-08

- Update dependencies

## [3.0.0] - 2024-07-05

- Mosaic Redesign

## [2.1.0] - 2023-12-08

- Update Vite to 5
- Update other dependencies

## [2.0.1] - 2023-10-04

- Dependencies update

## [2.0.0] - 2023-06-01

- Dark version added

## [1.7.4] - 2023-04-11

- Update dependencies

## [1.7.3] - 2023-02-13

- Further sidebar color improvements

## [1.7.2] - 2023-02-13

- Update dependencies
- Improve sidebar icons color logic

## [1.7.0] - 2022-08-30

- Update sidebar
- Fix mobile menu issue

## [1.6.0] - 2022-07-15

- Replace Sass with CSS files
- Update dependencies
- Update React to v18

## [1.3.1] - 2022-01-27

- Fix tailwind.config.js file

## [1.3.0] - 2022-01-25

- Replace CRA (Create React App) with Vite
- Remove Craco
- Update dependencies

## [1.2.0] - 2021-12-13

- Update Tailwind 3
- Several improvements

## [1.1.1] - 2021-11-23

- Alignment issue## [1.1.1] - 2021-11-23

- Alignment issue

## [1.1.0] - 2021-11-15

- Update dependencies
- Enable Tailwind JIT
- Add expandable / collapsible sidebar feature

## [1.0.0] - 2021-04-20

First release